import arcade
def window(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE):
    arcade.open_window(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
    arcade.set_background_color(arcade.color.WHITE)
    arcade.start_render()
    arcade.finish_render()
    arcade.run()