import VNE
import pygame
from pygame import mixer
pygame.init()
mixer.init()
mixer.music.load('music/Sus.mp3')
mixer.music.set_volume(1)
mixer.music.play()
VNE.window(1000, 600, "No")
